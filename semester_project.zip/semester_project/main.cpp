#include <iostream>

using namespace std;
int main() {
	char letter,input;
	string gender, name,allergies,staffid,blood_group,condition,inputpin;
	int pulse_rate,money;
    int idnumber;
	int choice,option;
	char letter1;
	float height,respiration_rate,glucose_level,blood_oxygen,blood_pressure,body_temp;
	float weight;
	cout<<" WELCOME TO THE ONLINE HOSPITAL\n ";
	cout<<"WOULD YOU LIKE TO ACCESS PATIENCE DATA OR STAFF DATA\n";
	mark:
	cout<<"ENTER 'S' FOR STAFF DATA AND 'P' FOR PATIENCE DATA AND 'I' FOR OTHER INFORMATION\n";
	cin>>letter;
	if(letter=='p'||letter=='P')

	{	cout<<"NEW PATIENT OR OLD PATIENT\n";
	cout<<"ENTER 'N' FOR NEW PATIENT OR 'O' FOR AN OLD PATIENT \n";
	cin>>letter1;
	if(letter1=='n'||letter1=='N'){
		cout<<"NEW PATIENTS HAVE TO BE REGISTERED\n";
		cout<<"BELOW ARE SOME REQUIRED INFORMATION ABOUT THE NEW PATIENT\n";
		  cout<<"PLEASE ENTER THE NAME OF THE NAME PATIENT:::\n";
		  cin>>name;
	cout<<"GENDER:\n";
	cin>>gender;
	
	cout<<"enter patients blood pressure\n";
	cin>>blood_pressure;
	cout<<"enter patients pulse rate\n";
	cin>>pulse_rate;
	cout<<"ALLERGIES:\n";
	cin>>allergies;
	cout<<"enter patients blood oxygen level\n";
	cin>>blood_oxygen;
	cout<<"enter patients respiration rate\n";
	cin>>respiration_rate;
	cout<<"enter patients glucose level\n";
	cin>>glucose_level;
	cout<<"enter body temperature\n";
	cin>>body_temp;
	cout<<"CONDITION:\n";
	cin>>condition;	
	cout<<"ENTER PATIENTS HEIGHT\n";
	cin>>height;
	cout<<"ENTER PATIENTS WEIGHT\n";
	cin>>weight;
	cout<<"BLOOD GROUP:\n";
	cin>>blood_group;
	cout<<"PATIENTS DATA IS BEING PROCCESSED\n";
	cout<<"UPDATE SUCCESSFUL\n";
	cout<<"WELCOME TO THE ONLINE HOSPITAL "<<name<<endl;
	
}else if(letter1=='o'||letter1=='O'){

cout<<"ENTER PATIENTS ID NUMBER\n";
cin>>idnumber;
	cout<<"gender:.............................\n";
	cout<<"condition:...........................\n";
	cout<<"enter patients height:.................\n";
	cout<<"enter patients weight:..................\n";
	cout<<"blood group:............................\n";
	cout<<"allegies:................................\n";
    cout<<"appointment with:.........................\n";
    cout<<"time of appointment is:................... .\n";
    cout<<"patients pulse rate:........................\n";
    cout<<"patients respiration rate:....................\n";
    cout<<"patients body temperature:.....................\n";
   	cout<<" patients blood oxygen level:..............\n";
   	cout<<" patients glucose level:....................\n";

}
}else if(letter=='s'||letter=='S'){
	cout<<"YOU HAVE REACHED THE ONLINE STAFF PAGE\n ";
			
		
	
	cout<<"ENTER THE IDENTITY NUMBER OF STAFF\n ";
	cin>>staffid;
	
	cout<<"WHAT INFORMATION WOULD YOU LIKE TO ACCESS ABOUT "<<staffid<<endl;
	cout<<"1. field of work\n";
	cout<<"2. salary\n";
	cout<<"3. appointments\n";
	cout<<"4. name\n";
	cin>>choice;
	switch(choice){
		
		case 1:cout<<staffid<<" works in the.................... department\n";
		return 0;
		case 2:cout<<staffid<<" receives a amount of........................ monthly\n";
		return 0;
		case 3:cout<<staffid<<" has appointments with...........................\n";
		return 0;
		case 4:cout<<staffid<<" is called.................................\n";
		return 0;
			}

	}	else if(letter=='i'||letter=='I')
	{move:
		cout<<"1.patient billing system\n";
		cout<<"2.request for an ambulance\n";
		cout<<"3.request to speak to manager\n";
		cout<<"4. insurance card\n";
		cin>>option;
		
		switch(option){bend:
			case 1:
				cout<<"choose methood of payment\n";
			    cout<<"press '1' to pay in cash or '2  to use mobile money service\n";
			 
			 cin>>money;
		switch(money){
			case 1:cout<<"PLEASE GO TO THE RECEPTIONIST AND MAKE ALL NECESSARY PAYMENTS\n";
			cout<<"YOU WILL BE GIVEN 2 RECEIPTS\n";
			cout<<"MAKE SURE TO CROSSCHECK THE RECIEPT BEFORE LEAVING THE DESK\n";
			cout<<"PLEASE GIVE A COPY TO THE SECUIRITY POST BEFORE YOU LEAVE\n";
			break;
			case 2:cout<<"please you can send the money to 025812342(BEND Clinic)and please use your name as your reference\n";
			cout<<"and go to the reception for a payment receiPt else you will not be allowed to leave the building\n";
			 
			 default:
			 	cout<<"Choose a valid option\n";
			 	goto bend;
		}			break;			

			case 2:
				cout<<"KINDLY WALK TO THE FRONT DESK AND STATE YOUR REASON FOR THE AMBULANCE\n";
				cout<<"GO TO THE GARAGE BEHIND THE PHARMACY AND SHOW THE GIVEN TICKET TO THE HANDLER WHO WILL THEN ASSIGN YOU A VEHICLE\n";			
			break;
			case 3:
			cout<<"TO SPEAK TO OUR MANAGER YOU MUST HAVE AN APPOINTMENT\n";
			cout<<"DO YOU HAVE AN APPOINTMENT\n";
			cout<<"ENTER 'Y' FOR YES AND 'N' FOR NO\n"; 
			cin>>input;
			if(input=='y'||input=='Y'){
				cout<<"PLEASE WAIT THE MANAGER WILL INVITE YOU IN DUE TIME\n";
		   } 
			else if(input=='n'||input=='N'){
				cout<<"TO MEET THE MANAGER YOU MUST FIRST BOOK AN APPOINTMENT\N";
				cout<<"KINDLY GO TO THE RECEPTIONIST TO ASSIST YOU IN BOOKING THE APPOINTMENT\n";
				cout<<"PLEASE WHEN THE TIME IS DUE THE MANAGER WILL INVITE YOU\N";
			}			
			case 4:
				cout<<"PERSONS WITH INSURANCE CARD ARE TO PAY ONLY ONLY HALF OF THEIR TOTAL COST\n";
				cout<<"KINDLY GO TO THE THIRD DESK AND YOU WILL BE SORTED IN NO TIME\n";
			
			default:
				cout<<"Wrong option\n";
				cout<<"please select the correct option\n";
				goto move;
			
		}
			
		
	}


	
	

	return 0;
}

